"""ploTTY: FSM plotter manager (headless-first) with vpype + per-session recording."""

from .cli import app

if __name__ == "__main__":
    app()
