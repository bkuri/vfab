from plotty.config import load_config


def test_cfg():
    assert load_config()
